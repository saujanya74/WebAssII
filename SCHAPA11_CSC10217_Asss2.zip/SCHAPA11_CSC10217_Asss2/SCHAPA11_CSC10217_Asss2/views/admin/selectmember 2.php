<?php require 'admin_nav.php'; ?>
<div class="right_panel">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1>Edit/Delete Member </h1>
		<p><b>Select User to Edit/Delete</b></p>
		<p>Users shown in dropdown as: Surname, Other names - Username</p>
		<br>
		<form method="post" action="<?php echo URL ?>admin/selectmember/<?php echo $_POST['member_id'] ?>">
			<div class="form1">
				<div class="form-group">
					<select name="member_id">
						<?php
							foreach($this->getMember as $MemberList) {
								echo "<option value='".$MemberList['member_id']."'>".$MemberList['surname'].", ".$MemberList['other_name']." - ".$MemberList['surname']."</option>";
							}
						?>
					</select><br>
					<button type="submit" name="button" class="btn btn-submit">Search</button>
				</div>
			</div>
		</form>
</div>
	<div class="clearfix"></div>
</div>
	