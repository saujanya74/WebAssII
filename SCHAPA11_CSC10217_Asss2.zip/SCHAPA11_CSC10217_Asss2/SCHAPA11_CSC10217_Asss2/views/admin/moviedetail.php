<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		$detail = $this->moviedetail;
		?>
		<h1>Edit <?php echo $detail['title'] ?></h1>
		
		<form method="post" action="<?php echo URL ?>admin/updatemovie" enctype="multipart/form-data">
			<div class="form1">
				<fieldset>
					<legend>New Movie:</legend>
					<div class="form-group">
						<label for="title">Title:</label>
						<input type="text" name="title" id="title" value="<?php echo $detail['title'] ?>">
					</div>
					<div class="form-group">
						<label for="year">Year:</label>
						<input type="text" name="year" id="year" value="<?php echo $detail['year'] ?>">
					</div>
					<div class="form-group">
						<label for="tagline">Tagline:</label>
						<input type="text" name="tagline" id="tagline" value="<?php echo $detail['tagline'] ?>">
					</div>
					
				</fieldset>
			</div>
			
			<div class="form1">
				<fieldset>
					<legend>Stock Information: </legend>
					<div class="form-group">
						<label for="rental_period">Rental Period:</label>
						<select name="rental_period" id="rental_period" required="">
							<option <?php if($detail['rental_period'] == "") echo "selected='selected'"; else echo ""; ?> value="">select...</option>
							<option <?php if($detail['rental_period'] == "3 Day") echo "selected='selected'"; else echo ""; ?> value="3 Day">3 Day</option>
							<option <?php if($detail['rental_period'] == "Weekly") echo "selected='selected'"; else echo ""; ?> value="Weekly">Weekly</option>
							<option <?php if($detail['rental_period'] == "Overnight") echo "selected='selected'"; else echo ""; ?> value="Overnight">Overnight</option>
						</select>
					</div>
					<fieldset>
						<legend>DVD: </legend>
						<div class="form-group">
							<label for="DVD_rental_price">Rental price:</label>
							<input type="text" name="DVD_rental_price" id="DVD_rental_price" required="" value="<?php echo $detail['DVD_rental_price'] ?>">
						</div>
						<div class="form-group">
							<label for="DVD_purchase_price">Purchase price:</label>
							<input type="text" name="DVD_purchase_price" id="DVD_purchase_price" required="" value="<?php echo $detail['DVD_purchase_price'] ?>">
						</div>
						<div class="form-group">
							<label for="numDVD">In stock:</label>
							<input type="text" name="numDVD" id="numDVD" required="" value="<?php echo $detail['numDVD'] ?>">
						</div>
						<div class="form-group">
							<label for="numDVDout">Rented:</label>
							<input type="text" name="numDVDout" id="numDVDout" required="" value="<?php echo $detail['numDVDout'] ?>">
						</div>
					</fieldset><br>
					<fieldset>
						<legend>BluRay: </legend>
						<div class="form-group">
							<label for="BluRay_rental_price">Rental price:</label>
							<input type="text" name="BluRay_rental_price" id="BluRay_rental_price" required="" value="<?php echo $detail['BluRay_rental_price'] ?>">
						</div>
						<div class="form-group">
							<label for="BluRay_purchase_price">Purchase price:</label>
							<input type="text" name="BluRay_purchase_price" id="BluRay_purchase_price" required="" value="<?php echo $detail['BluRay_purchase_price'] ?>">
						</div>
						<div class="form-group">
							<label for="numBluRay">In stock:</label>
							<input type="text" name="numBluRay" id="numBluRay" required="" value="<?php echo $detail['numBluRay'] ?>">
						</div>
						<div class="form-group">
							<label for="numBluRayOut">Rented:</label>
							<input type="text" name="numBluRayOut" id="numBluRayOut" required="" value="<?php echo $detail['numBluRayOut'] ?>">
						</div>
					</fieldset>
				</fieldset><br>
				<fieldset style="text-align:center;">
					<legend></legend>
					<input type="hidden" name="movie_id" value="<?php echo $detail['movie_id'] ?>">
					<button type="submit" name="button" class="btn btn-submit">Submit</button>
				</fieldset>
			</div>
		</form>
		<form method="post" action="<?php echo URL ?>admin/deletemovie">
			<div class="form1">
				<fieldset style="text-align:center;">
					<legend></legend>
					<input type="hidden" name="movie_id" value="<?php echo $detail['movie_id'] ?>">
					<button type="submit" name="delete" class="btn btn-reset">Delete</button>
				</fieldset>
			</div>
		</form>
	</div>
</div>
	<div class="clearfix"></div>
</div>