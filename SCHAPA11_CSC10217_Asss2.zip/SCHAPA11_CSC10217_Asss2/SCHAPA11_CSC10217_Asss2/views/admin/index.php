<?php require 'admin_nav.php'; ?>
<div class="right_panel">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1>Welcome <?php echo Session::get('fullname') ?></h1>
		<p align="center">Please select an action from the menu.</p>
</div>
<div class="clearfix"></div>
</div>