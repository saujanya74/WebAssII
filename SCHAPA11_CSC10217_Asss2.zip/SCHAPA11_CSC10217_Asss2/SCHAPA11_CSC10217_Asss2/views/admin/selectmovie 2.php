<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1>Edit/Delete Movie </h1>
		<p><b>Select Movie to Edit/Delete</b></p>
		<p>Users shown in dropdown as: Title - Year</p>
		<br>
		<form method="post" action="<?php echo URL ?>admin/selectmovie/<?php echo $_POST['movie_id'] ?>">
			<div class="form1">
				<div class="form-group">
					<select name="movie_id">
						<?php
							foreach($this->getmovie as $movieList) {
								echo "<option value='".$movieList['movie_id']."'>".$movieList['title']." - ".$movieList['year']."</option>";
							}
						?>
					</select><br>
					<button type="submit" name="button" class="btn btn-submit">Search</button>
				</div>
			</div>
		</form>
	</div>
</div>
	<div class="clearfix"></div>
</div>
	