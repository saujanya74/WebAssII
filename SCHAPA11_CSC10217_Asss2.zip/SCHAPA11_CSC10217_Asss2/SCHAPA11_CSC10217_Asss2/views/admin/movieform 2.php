<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1>New Movie Form</h1>
		
		<form method="post" action="<?php echo URL ?>admin/addmovie" enctype="multipart/form-data">
			<div class="form1">
				<fieldset>
					<legend>New Movie:</legend>
					<div class="form-group">
						<label for="title">Title:</label>
						<input type="text" name="title" id="title" required="">
					</div>
					<div class="form-group">
						<label for="year">Year:</label>
						<input type="text" name="year" id="year" required="">
					</div>
					<div class="form-group">
						<label for="tagline">Tagline:</label>
						<input type="text" name="tagline" id="tagline" required="">
					</div>
					<div class="form-group">
						<label for="plot">Plot:</label>
						<textarea  name="plot" id="plot" cols="65" rows="6"></textarea>
					</div>
					<div class="form-group">
						<label for="poster">Poster:</label>
						<input type="file" name="poster" id="poster" required="">
					</div>
					<div class="form-group">
						<label for="director_id">Director:</label>
						<select name="director_id" id="director_id" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->director_list as $director) {
								echo "<option value='".$director['director_id']."'>".$director['director_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="director_name">Or new director:</label>
						<input type="text" name="director_name" id="director_name">
					</div>
					<div class="form-group">
						<label for="studio_id">Studio:</label>
						<select name="studio_id" id="studio_id" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->studio_list as $studio) {
								echo "<option value='".$studio['studio_id']."'>".$studio['studio_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="studio_name">Or new studio:</label>
						<input type="text" name="studio_name" id="studio_name">
					</div>
					<div class="form-group">
						<label for="genre_id">Genre:</label>
						<select name="genre_id" id="genre_id" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->genre_list as $genre) {
								echo "<option value='".$genre['genre_id']."'>".$genre['genre_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="genre_name">Or new genre:</label>
						<input type="text" name="genre_name" id="genre_name">
					</div>
					<div class="form-group">
						<label for="classification">Classification:</label>
						<select name="classification" id="classification" required="">
							<option value="">Select...</option>
							<option value="G">G</option>
							<option value="M">M</option>
							<option value="MA">MA</option>
							<option value="PG">PG</option>
							<option value="R">R</option>
						</select>
					</div>
				</fieldset>
			</div>
			<div class="form1">
				<fieldset>
					<legend>Movie Stars and Co-stars:</legend>
					<div class="form-group">
						<label for="star1">First Star:</label>
						<select name="star1" id="star1" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="star1new">Or new first start:</label>
						<input type="text" name="star1new" id="star1new">
					</div>
					<div class="form-group">
						<label for="star2">Second Star:</label>
						<select name="star2" id="star2" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="star2new">Or new second star:</label>
						<input type="text" name="star2new" id="star2new">
					</div>
					<div class="form-group">
						<label for="star3">Third Star:</label>
						<select name="star3" id="star3" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="star3new">Or new third star:</label>
						<input type="text" name="star3new" id="star3new">
					</div>
					<div class="form-group">
						<label for="costar1">First Co-star:</label>
						<select name="costar1" id="costar1" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="costar1new">Or new first co-star:</label>
						<input type="text" name="costar1new" id="costar1new">
					</div>
					<div class="form-group">
						<label for="costar2">Second Co-star:</label>
						<select name="costar2" id="costar2" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="costar2new">Or new second co-star:</label>
						<input type="text" name="costar2new" id="costar2new">
					</div>
					<div class="form-group">
						<label for="costar3">Third Co-star:</label>
						<select name="costar3" id="costar3" required="">
							<option value="">Select...</option>
							<?php 
							foreach ($this->actor_list as $actor) {
								echo "<option value='".$actor['actor_id']."'>".$actor['actor_name']."</option>";
							}
							?>
						</select>
					</div>
					<div class="form-group">
						<label for="costar3new">Or new third co-star:</label>
						<input type="text" name="costar3new" id="costar3new">
					</div>
				</fieldset>
			</div>
			<div class="form1">
				<fieldset>
					<legend>Stock Information: </legend>
					<div class="form-group">
						<label for="rental_period">Rental Period:</label>
						<select name="rental_period" id="rental_period" required="">
							<option value="">select...</option>
							<option value="3 Day">3 Day</option>
							<option value="Weekly">Weekly</option>
							<option value="Overnight">Overnight</option>
						</select>
					</div>
					<fieldset>
						<legend>DVD: </legend>
						<div class="form-group">
							<label for="DVD_rental_price">Rental price:</label>
							<input type="text" name="DVD_rental_price" id="DVD_rental_price" required="">
						</div>
						<div class="form-group">
							<label for="DVD_purchase_price">Purchase price:</label>
							<input type="text" name="DVD_purchase_price" id="DVD_purchase_price" required="">
						</div>
						<div class="form-group">
							<label for="numDVD">In stock:</label>
							<input type="text" name="numDVD" id="numDVD" required="">
						</div>
						<div class="form-group">
							<label for="numDVDout">Rented:</label>
							<input type="text" name="numDVDout" id="numDVDout" required="">
						</div>
					</fieldset><br>
					<fieldset>
						<legend>BluRay: </legend>
						<div class="form-group">
							<label for="BluRay_rental_price">Rental price:</label>
							<input type="text" name="BluRay_rental_price" id="BluRay_rental_price" required="">
						</div>
						<div class="form-group">
							<label for="BluRay_purchase_price">Purchase price:</label>
							<input type="text" name="BluRay_purchase_price" id="BluRay_purchase_price" required="">
						</div>
						<div class="form-group">
							<label for="numBluRay">In stock:</label>
							<input type="text" name="numBluRay" id="numBluRay" required="">
						</div>
						<div class="form-group">
							<label for="numBluRayOut">Rented:</label>
							<input type="text" name="numBluRayOut" id="numBluRayOut" required="">
						</div>
					</fieldset>
				</fieldset><br>
				<fieldset style="text-align:center;">
						<legend></legend>
						<button type="submit" name="button" class="btn btn-submit">Submit</button>
						<button type="reset" name="reset" class="btn btn-reset">Reset</button>
					</fieldset>
			</div>
		</form>
	</div>
</div>
	<div class="clearfix"></div>
</div>