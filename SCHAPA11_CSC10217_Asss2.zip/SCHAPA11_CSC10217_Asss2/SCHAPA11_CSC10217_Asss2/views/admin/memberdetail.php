<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		$detail = $this->memberdetail;
		?>
		<h1><?php echo $detail['surname'].' '.$detail['other_name'] ?></h1>
		

		<div class="form">
			<form id="joinform" name="joinform" method="post" action="<?php echo URL ?>admin/updatemember">
				<div class="form1">
					<fieldset>
						<legend>Member ID: <?php echo $detail['member_id'] ?> &nbsp;</legend>
						<div class="form-group">
							<label for="#" id="sur">Surname:</label>
							<input type="text" name="Name" id="isur" required="" value="<?php echo $detail['surname'] ?>">
						</div>
						<div class="form-group">
							<label for="#" id="onam">Other names:</label>
							<input type="text" name="othername" required="" value="<?php echo $detail['other_name'] ?>">
						</div>
						<div class="form-group">
							<label for="#">Occupation:</label>
							<select name="occcupation" id="occup" required="">
								<option <?php if($detail['occupation'] == "Student") echo "selected='selected'"; else echo ""; ?> value="Student">Student</option>
								<option <?php if($detail['occupation'] == "Manager") echo "selected='selected'"; else echo ""; ?> value="Manager">Manager</option>
								<option <?php if($detail['occupation'] == "Medical") echo "selected='selected'"; else echo ""; ?> value="Medical worker">Medical worker</option>
								<option <?php if($detail['occupation'] == "Trades") echo "selected='selected'"; else echo ""; ?> value="Trades worker">Trades worker</option>
								<option <?php if($detail['occupation'] == "Education") echo "selected='selected'"; else echo ""; ?> value="Education">Education</option>
								<option <?php if($detail['occupation'] == "Technician") echo "selected='selected'"; else echo ""; ?> value="Technician">Technician</option>
								<option <?php if($detail['occupation'] == "Clerical") echo "selected='selected'"; else echo ""; ?> value="Clerical worker">Clerical worker</option>
								<option <?php if($detail['occupation'] == "Retail") echo "selected='selected'"; else echo ""; ?> value="Retail worker">Retail worker</option>
								<option <?php if($detail['occupation'] == "Researcher") echo "selected='selected'"; else echo ""; ?> value="Researcher">Researcher</option>
								<option <?php if($detail['occupation'] == "Others") echo "selected='selected'"; else echo ""; ?> value="Others">Others</option>
							</select>
						</div>
						<div class="form-group">
							<label for="#">Username:</label>
							<input type="text" id="username" value="<?php echo $detail['username'] ?>" readonly >
							<div class="popup" id = "usernamehelp">
				              Please enter username<br>minimum 6 characters - maximum 10 characters
				           </div>
						</div>
						<div class="form-group">
							<label for="#">Password:</label>
							<input type="text" name="password" id="password" required="" value="<?php echo $detail['password'] ?>">
							<div class="popup" id = "passwordhelp">
				              10 characters maximum containing at minimum of<br>one uppercase letter,<br>
				              one lowercase letter,<br>one number and<br>one special character<br> 
				              with no whitespace allowed
				           </div>
						</div>
						<div class="form-group">
							<label for="#" id="onam">Joined date:</label>
							<input type="text" readonly="" value="<?php echo $detail['join_date'] ?>">
						</div>
					</fieldset>
					
				</div>
				<div class="form1" id="preferredcontact">
					<fieldset>
						<legend>Contact Detail</legend>
						<label for="#">Contact Method</label>
						<label>Mobile phone: 
							<input type="radio" <?php if($detail['contact_method'] == "mobile") echo "checked='checked'"; else echo ""; ?> name="contactmethod" id="selectmobile" value="mobile"></label>
						<label>Landline phone: 
							<input type="radio" <?php if($detail['contact_method'] == "landline") echo "checked='checked'"; else echo ""; ?> name="contactmethod" id="selectlandline" value="landline"></label>
						<label>Email: 
							<input type="radio" <?php if($detail['contact_method'] == "email") echo "checked='checked'"; else echo ""; ?> name="contactmethod" id="selectemail" value="email"></label>
							<div class="popup" id = "contacthelp">
					           <p>Please select your preferred contact method.</p>
					        </div>

					<!-- </fieldset>
				</div>
				<div class="form1 cont">
					<fieldset>
						<legend>Contact details</legend> -->
						<div class="form-group">
							<label for="#">Mobile</label>
							<input type="text" name="mobile" id="mobile" class="contactinput" value="<?php echo $detail['mobile'] ?>">
							<div class="popup" id = "mobilehelp">
				              Enter mobile number in following format:<br>
				              0[4 or 5]XX XXX XXX where X is a digit
				           </div> 
						</div>
						<div class="form-group">
							<label for="#">Landline:</label>
							<input type="text" name="landline_number" id="landline_number" class="contactinput" value="<?php echo $detail['landline'] ?>">
							<div class="popup" id = "phonehelp">
				              Enter phone number in following format:<br>
				              (0[2,3,6,7,8 or 9]) XXXXXXXX where X is a digit
				           </div>
						</div>
						<div class="form-group">
							<label for="#">E-mail</label>
							<input type="text" name="email" id="email" class="contactinput" value="<?php echo $detail['email'] ?>">
							<div class="popup" id = "emailhelp">
				              Please enter valid email address
				           </div>
						</div>
					</fieldset>
				</div>
			
				<div class="form1">
					<fieldset>
						<legend>Address</legend>
						<label class="full-width">
						<input type="checkbox" name="magazine" id="magazine" value="1" <?php if($detail['magazine'] == "1") echo "checked='checked'"; else echo ""; ?> />
						Do you want to receive our monthly magazine?</label>
						<div class="form-group">
							<label for="">Street address:</label>
							<input type="text" name="street_name" id="street_name" value="<?php echo $detail['street'] ?>">
							<div class="popup" id = "streethelp">
				                Please enter house number and street address
				            </div>  
						</div>
						<div class="form-group">
							<label for="#">Suburb and State:</label>
							<input type="text" name="suburb_name" id="suburb_name" value="<?php echo $detail['suburb'] ?>">
							<div class="popup" id = "suburbhelp">
				                Please enter suburb and state separated by comma:<br>
				                Suburb, State
				            </div>   
						</div>
						<div class="form-group">
							<label for="#">Postcode:</label>
							<input type="text" name="postal_code" id="postal_code" value="<?php echo $detail['postcode'] ?>">
							<div class="popup" id = "postcodehelp">
				                Please enter postcode maximum 4 digits
				            </div>  
						</div>
					</fieldset>
				</div>
				
				<div class="form1">
					<fieldset style="text-align:center;">
						<legend></legend>
						<input type="hidden" name="member_id" value="<?php echo $detail['member_id'] ?>">
						<input type="hidden" name="selected_member" value="<?php echo $detail['surname'].' '.$detail['other_name'].' - '.$detail['username'] ?>">
						<button type="submit" name="update" class="btn btn-submit">Update</button>
					</fieldset>
				</div>
			</form>
			<form method="post" action="<?php echo URL ?>admin/deletemember">
				<div class="form1">
					<fieldset style="text-align:center;">
						<legend></legend>
						<input type="hidden" name="member_id" value="<?php echo $detail['member_id'] ?>">
						<input type="hidden" name="selected_member" value="<?php echo $detail['surname'].' '.$detail['other_name'].' - '.$detail['username'] ?>">
						<button type="submit" name="delete" class="btn btn-reset">Delete</button>
					</fieldset>
				</div>
			</form>
			
		</div>
	</div>
</div>
	<div class="clearfix"></div>
</div>
