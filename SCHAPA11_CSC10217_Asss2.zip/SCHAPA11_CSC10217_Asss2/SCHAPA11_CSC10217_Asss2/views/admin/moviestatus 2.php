<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1><?php echo $this->pagetitle ?></h1>
		<p align="center"><?php echo $this->pagedesc ?></p>
		<p align="center">Page will be redirected to the dashboard</p>
		<meta http-equiv="refresh" content="5;url=<?php echo URL ?>admin"> 

	</div>
</div>
</div>