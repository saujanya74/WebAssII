<div class="movie-content">
	<div class="Left_panel">
		<h1>Admin Menu</h1>
		<div class="navigation">
			<ul>
				<li><a href="<?php echo URL ?>admin/selectmember">Edit/Delete Member</a></li>
				<li><a target="_blank" href="<?php echo URL ?>join">Create New Member</a></li>
				<li><a href="<?php echo URL ?>admin/movieform">Enter New Movie</a></li>
				<li><a href="<?php echo URL ?>admin/selectmovie">Edit/Delete Movie</a></li>
				<li><a href="<?php echo URL ?>admin/logout">Logout</a></li>
			</ul>
		</div>
	</div>