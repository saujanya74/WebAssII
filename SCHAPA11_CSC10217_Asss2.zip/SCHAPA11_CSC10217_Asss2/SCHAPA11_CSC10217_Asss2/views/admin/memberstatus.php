<?php require 'admin_nav.php'; ?>
<div class="right_panel">
	<div class="">
		<?php
		if(Session::get('loggedIn') > 0)
		{
			echo "Admin-mode";
		}
		?>
		<h1>Edit/Delete Member</h1>
		<p align="center"><?php echo $this->selected_member ?></p>
	</div>
</div>
</div>