
	<div class="Aside">
		<h2>Sign-up now and start booking your movies on-line!</h2>
		<div class="form">
			<form id="joinform" name="joinform" method="post" action="<?php echo URL ?>join/addmember">
				<div class="form1">
					<fieldset>
						<legend>Name</legend>
						<div class="form-group">
							<label for="#" id="sur">Surname:</label>
							<input type="text" name="Name" id="isur" required="">
						</div>
						<div class="form-group">
							<label for="#" id="onam">Other names:</label>
							<input type="text" name="othername" required="">
						</div>
					</fieldset>
					
				</div>
				<div class="form1" id="preferredcontact">
					<fieldset>
						<legend>Preferred Contact Method</legend>
						<label>Mobile phone: 
							<input type="radio" name="contactmethod" id="selectmobile" value="mobile"></label>
						<label>Landline phone: 
							<input type="radio" name="contactmethod" id="selectlandline" value="landline"></label>
						<label>Email: 
							<input type="radio" name="contactmethod" id="selectemail" value="email" checked="checked"></label>
							<div class="popup" id = "contacthelp">
					           <p>Please select your preferred contact method.</p>
					        </div>

					</fieldset>
				</div>
				<div class="form1 cont">
					<fieldset>
						<legend>Contact details</legend>
						<div class="form-group">
							<label for="#">Mobile</label>
							<input type="text" name="mobile" id="mobile" class="contactinput">
							<div class="popup" id = "mobilehelp">
				              Enter mobile number in following format:<br>
				              0[4 or 5]XX XXX XXX where X is a digit
				           </div> 
						</div>
						<div class="form-group">
							<label for="#">Landline:</label>
							<input type="text" name="landline_number" id="landline_number" class="contactinput">
							<div class="popup" id = "phonehelp">
				              Enter phone number in following format:<br>
				              (0[2,3,6,7,8 or 9]) XXXXXXXX where X is a digit
				           </div>
						</div>
						<div class="form-group">
							<label for="#">E-mail</label>
							<input type="text" name="email" id="email" class="contactinput" required>
							<div class="popup" id = "emailhelp">
				              Please enter valid email address
				           </div>
						</div>
					</fieldset>
				</div>
				<div class="form1">
					<fieldset>
						<legend>Choose your occupation</legend>
						<label for="#">Occupation:</label>
						<select name="occcupation" id="occup" required="">
							<option value="Student">Student</option>
							<option value="Manager">Manager</option>
							<option value="Medical worker">Medical worker</option>
							<option value="Trades worker">Trades worker</option>
							<option value="Education">Education</option>
							<option value="Technician">Technician</option>
							<option value="Clerical worker">Clerical worker</option>
							<option value="Retail worker">Retail worker</option>
							<option value="Researcher">Researcher</option>
							<option value="Others">Others</option>
						</select>
					</fieldset>
				</div>
				<div class="form1">
					<fieldset>
						<legend>Address</legend>
						<label class="full-width">
						<input type="checkbox" name="magazine" id="magazine" value="1" checked ="checked" />
						Do you want to receive our monthly magazine?</label>
						<div class="form-group">
							<label for="">Street address:</label>
							<input type="text" name="street_name" id="street_name" required="">
							<div class="popup" id = "streethelp">
				            </div>  
						</div>
						<div class="form-group">
							<label for="#">Suburb and State:</label>
							<input type="text" name="suburb_name" id="suburb_name" required="">
							<div class="popup" id = "suburbhelp">
				            </div>   
						</div>
						<div class="form-group">
							<label for="#">Postcode:</label>
							<input type="text" name="postal_code" id="postal_code" required="">
							<div class="popup" id = "postcodehelp">
				            </div>  
						</div>
					</fieldset>
				</div>
				<div class="form1">
					<fieldset>
						<legend>Username and Password:</legend>
						<div class="form-group">
							<label for="#">Username:</label>
							<input type="text" name="username" id="username" required="">
							<div class="popup" id = "usernamehelp">
				           </div>
						</div>
						<div class="form-group">
							<label for="#">Password:</label>
							<input type="password" name="password" id="password" required="">
							<div class="popup" id = "passwordhelp">
				           </div>
						</div>
						<div class="form-group">
							<label for="">Verify Password:</label>
							<input type="password" name="verify_password" id="verify_password" required="">
							<div class="popup" id = "verifypasshelp">
				              <p>Enter password again for verification</p>
				           </div> 
						</div>
					</fieldset>
				</div>
				<div class="form1">
					<fieldset style="text-align:center;">
						<legend></legend>
						<button type="submit" name="button" class="btn btn-submit">Join the DVD E-Rental Now</button>
						<button type="reset" name="reset" class="btn btn-reset">Reset</button>
					</fieldset>
				</div>
			</form>
			<div id="para">
				<p>Privacy Notice: We take your privacy seriously and guarantee your data will not be shared with any third party.</p>
			</div>
		</div>
	</div>
</div>