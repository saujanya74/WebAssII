<div class="content">
	<div class="page-info">
		<h1>Membership Processing</h1>
		<p>Congratulations! You are now our official member. Please feel free to visit our site</p>
	</div>

</div>