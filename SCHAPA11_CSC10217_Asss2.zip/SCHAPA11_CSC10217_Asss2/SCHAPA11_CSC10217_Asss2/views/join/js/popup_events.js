
//Event handlers
function contactChange(event){
    var mobileMarker = document.getElementById("selectmobile");
    var phoneMarker = document.getElementById("selectlandline");    
    var emailMarker = document.getElementById("selectemail");  
    
    //Remove old markers
    mobileMarker.style.visibility = "hidden";
    phoneMarker.style.visibility = "hidden";
    emailMarker.style.visibility = "hidden";                                   
    
    //Show marker in right elements
    switch (event.currentTarget.value) {
        case "mobile":
                    mobileMarker.style.visibility = "visible";    
                    break;
        case "landline":
                    phoneMarker.style.visibility = "visible";        
                    break;
        case "email":
                    emailMarker.style.visibility = "visible";          
                    break;                    
    }    
}


function magazineChange(event){
    var streetMarker = document.getElementById("streetmarker");
    var suburbMarker = document.getElementById("suburbmarker");    
    var postcodeMarker = document.getElementById("postcodemarker");            

    if(event.currentTarget.checked == true){
        //Mark address elements as compulsory
          
        //Add markers to all the address elements.
        streetMarker.style.visibility = "visible";
        suburbMarker.style.visibility = "visible";
        postcodeMarker.style.visibility = "visible";            
    }else {
        //Unmark address elements as compulsory
        streetMarker.style.visibility = "hidden";
        suburbMarker.style.visibility = "hidden";
        postcodeMarker.style.visibility = "hidden";            
        
        //clear any hilights
        clearHilight("streetrow");
        clearHilight("suburbrow");
        clearHilight("postcoderow");  
    }

}



function displayPopup(element, event){
    var popupWindow = $('#'+element);
    mousey = event.pageY + 14 + "px";    
    mousex = event.pageX + 14 + "px";   
    popupWindow.css({
        top: mousey, 
        left: mousex,
        display: "block",
        position: "absolute"
    });
      
         
}

function hidePopup(element){
    $('#'+element).css({
        display: "none"
    });
}

function helpPopup(event){
    switch(event.currentTarget.id){
        case "preferredcontact" :
            displayPopup("contacthelp", event);        
            break;
        case "mobile" :
            displayPopup("mobilehelp", event);        
            break;
        case "landline_number" :
            displayPopup("phonehelp", event);        
            break;
        case "email" :
            displayPopup("emailhelp", event);        
            break;
        case "street_name" :
            displayPopup("streethelp", event);        
            break;
        case "suburb_name" :
            displayPopup("suburbhelp", event);        
            break;
        case "postal_code" :
            displayPopup("postcodehelp", event);        
            break;
        case "username" :
            displayPopup("usernamehelp", event);        
            break;
        case "password" :
            displayPopup("passwordhelp", event);        
            break;
        case "verify_password" :
            displayPopup("verifypasshelp", event);        
            break;            
    }
}

function helpPopdown(event){
    switch(event.currentTarget.id){
        case "preferredcontact" :
            hidePopup("contacthelp");        
            break;
        case "mobile" :
            hidePopup("mobilehelp");        
            break;
        case "landline_number" :
            hidePopup("phonehelp");        
            break;
        case "email" :
            hidePopup("emailhelp");        
            break;
        case "street_name" :
            hidePopup("streethelp");        
            break;
        case "suburb_name" :
            hidePopup("suburbhelp");        
            break;
        case "postal_code" :
            hidePopup("postcodehelp");        
            break;
        case "username" :
            hidePopup("usernamehelp");        
            break;
        case "password" :
            hidePopup("passwordhelp");        
            break;
        case "verify_password" :
            hidePopup("verifypasshelp");        
            break;            
    }
}
