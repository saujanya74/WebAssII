$(function(){
	
	//Help pop-up events
	$('#preferredcontact').on('mousemove', helpPopup);
	$('#preferredcontact').on('mouseout', helpPopdown);

	$('#mobile').on('mousemove', helpPopup);
	$('#mobile').on('mouseout', helpPopdown);

	$('#landline_number').on('mousemove', helpPopup);
	$('#landline_number').on('mouseout', helpPopdown);

	$('#email').on('mousemove', helpPopup);
	$('#email').on('mouseout', helpPopdown);

	$('#street_name').on('mousemove', helpPopup);
	$('#street_name').on('mouseout', helpPopdown);

	$('#suburb_name').on('mousemove', helpPopup);
	$('#suburb_name').on('mouseout', helpPopdown);

	$('#postal_code').on('mousemove', helpPopup);
	$('#postal_code').on('mouseout', helpPopdown);
	    
	$('#username').on('mousemove', helpPopup);
	$('#username').on('mouseout', helpPopdown);

	$('#password').on('mousemove', helpPopup);
	$('#password').on('mouseout', helpPopdown);

	$('#verify_password').on('mousemove', helpPopup);
	$('#verify_password').on('mouseout', helpPopdown);

})