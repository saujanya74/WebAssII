$(function(){
	$('.form-group:has(input[required]) > input')
        .after('<span class="form-addin-danger">*</span>');  
    $('.form1 > fieldset:has(select[required]) > select')
        .after('<span class="form-addin-danger">*</span>');

    $('input[type=radio]').change(function(){
    	selectid = $(this).attr("id")
    	if(selectid == "selectmobile")
    	{
    		$('.cont .form-group:has(span) > span').remove('span');
    		$('.contactinput').prop('required',false)
    		$('#mobile').prop('required',true)
    		$('.form-group').find('input[id=mobile]').attr('required');  
    		$('.cont .form-group:has(input[id=mobile]) > input').after('<span class="form-addin-danger">*</span>');  
    	}
    	else if(selectid == "selectlandline")
    	{	
    		$('.cont .form-group:has(span) > span').remove('span');
    		$('.contactinput').prop('required',false)
    		$('#landline_number').prop('required',true)
    		$('.form-group').find('input[id=landline_number]').attr('required');  
    		$('.cont .form-group:has(input[id=landline_number]) > input').after('<span class="form-addin-danger">*</span>');  
    	}
    	else if(selectid == "selectemail")
    	{	
    		$('.cont .form-group:has(span) > span').remove('span');
    		$('.contactinput').prop('required',false)
    		$('#email').prop('required',true)
    		$('.form-group').find('input[id=email]').attr('required');  
    		$('.cont .form-group:has(input[id=email]) > input').after('<span class="form-addin-danger">*</span>');  
    	}
    })  

    $('input[name=magazine]').change(function(){
        if($(this).is(':checked'))
        {
            $('#street_name').prop('required',true).after('<span class="form-addin-danger">*</span>')
            $('#suburb_name').prop('required',true).after('<span class="form-addin-danger">*</span>')
            $('#postal_code').prop('required',true).after('<span class="form-addin-danger">*</span>')
        }
        else
        {
            $('#street_name').prop('required',false).next('span').remove()
            $('#suburb_name').prop('required',false).next('span').remove()
            $('#postal_code').prop('required',false).next('span').remove()
        }
    })
})