<div class="footer">
			<p>Copyright &copy; saujanya chapagain</p>
		</div>
	</div>
</body>
</html>