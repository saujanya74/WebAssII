
	<div class="Aside">
		<h2>Welcome to the Movie Rental System</h2>
		<p><B>DVD Emporium</B> is known for its high quality and customer service.<br>
			We are dedicated to procuring he finest movies for our customers.<br>
			DVD was the premier digital video storage medium of the 20th century,<br>
			and now you too can enjoy the crisp visuals and clean audio of DVD as<br>
		well as the improved quality of the 21st century's storage medium of choice BluRay. <br> </p>
		<p><b>O</b>ur shop, conveniently located near Southern Cross University at the Gold Coast
			contains literally thousands of new and quality pre-loved DVDs and BluRays
			available for your viewing pleasure. Rent or purchase its up to you. Consider
			becoming a member as this will allow you to book on-line and save you the
			disappointment of arriving only to find the movie you were wishing to view or
		purchase is currently out of stock.</p>
		<p><b>T</b>o become a member please <a href="<?php echo URL ?>join">join up.</a></p>
		<p><b>Y</b>ou can view our extensive movie database in the <a href="<?php echo URL ?>moviezone">MovieZone.</a></p>
		<p><b>A</b>s an additional service to our clientele our resident IT guru provides weekly advice on important developments in the IT industry. View the advice from our store IT expert in the <a href="<?php echo URL ?>techzone">TechZone.</a></p>
	</div>
</div>