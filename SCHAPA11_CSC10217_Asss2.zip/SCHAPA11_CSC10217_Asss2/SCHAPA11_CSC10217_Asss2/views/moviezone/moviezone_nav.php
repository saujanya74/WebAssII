<div class="movie-content">
			<div class="Left_panel">
				<?php
		if(Session::get("loggedIn") == true)
		{
			echo "<h4>Logged in as : ".Session::get("fullname")."</h4>";
		}
		?>
				<h1>Search Menu</h1>
				<div class="navigation">
					<ul>
						<li><a href="<?php echo URL ?>moviezone/showall">Show all movies</a></li>
						<li><a href="<?php echo URL ?>moviezone/newreleases">New Releases</a></li>
						<li><a href="<?php echo URL ?>moviezone/actor">Search by Actor</a></li>
						<li><a href="<?php echo URL ?>moviezone/director">Search by Director</a></li>
						<li><a href="<?php echo URL ?>moviezone/genre">Search by Genre</a></li>
						<li><a href="<?php echo URL ?>moviezone/classification">Search by Classification</a></li>
					</ul>
					<h1>User Menu</h1>
					<ul>
						<?php if(Session::get("loggedIn") == true): ?>
							<li><a href="<?php echo URL ?>moviezone/checkout">Checkout</a></li>
						<?php else: ?>
							<li><a href="<?php echo URL ?>moviezone/login">Log In</a></li>
						<?php endif; ?>
						<li><a href="<?php echo URL ?>moviezone/logout">Log Out</a></li>
						<li><a href="<?php echo URL ?>login">Admin</a></li>
					</ul>
				</div>
			</div>