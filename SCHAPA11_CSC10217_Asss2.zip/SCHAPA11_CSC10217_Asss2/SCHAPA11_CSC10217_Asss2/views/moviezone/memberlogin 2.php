<?php require 'moviezone_nav.php'; ?>
<div class="right_panel">
	<h1>Member Login</h1>
	<form method="post" action="<?php echo URL ?>moviezone/checklogin">
		<div class="form1">
			<fieldset>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="txtuser">
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="txtpass">
				</div>
				<div class="form-group">
					<label>&nbsp;</label>
					<button type="submit" name="memlogin">Login</button>
				</div>
			</fieldset>
		</div>
	</form>
	</div>
	<div class="clearfix"></div>
</div>