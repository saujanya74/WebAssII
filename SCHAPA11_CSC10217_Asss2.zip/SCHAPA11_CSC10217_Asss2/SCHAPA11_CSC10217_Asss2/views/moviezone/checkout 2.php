<?php require 'moviezone_nav.php'; ?>
<div class="right_panel">
	<?php
	if(Session::get('loggedIn') == true)
	{
		echo "<p>".count($_SESSION['basket'])." movies selected</p>";
	}
	?>
	<h1>Checkout</h1>
	<p align="center">This module is currently being built and has not yet been completed</p>
	<p align="center">You have chosen the following movies to be booked/purchased:</p><br>
	<div class="checkout_main">
		<?php
		foreach ($this->basketmovies as $item) {
		?>
		<div class="checkout" style="margin-bottom: 15px;">
			<div class="left">
				<p><b>Movie Title:</b> <?php echo $item['title'] ?></p>
				<p><b>Year:</b> <?php echo $item['year'] ?></p>
				<p><b><?php echo $item['tagline'] ?></b></p>
				<p><b>Availability:</b>
					<?php
					$con = 0;
					$dvd_a = $item['numDVD'] - $item['numDVDout'];
					$blu_a = $item['numBluRay'] - $item['numBluRayOut'];
					if($dvd_a > 0)
					{
						$con = 1;
						echo "Only ".$dvd_a." DVD are available";
					}
					if($blu_a > 0)
					{
						echo $con == 1 ? " and only " : "Only ";
						echo $dvd_a." BluRay are available";
					}
					?>
				</p>
			</div>
			<div class="right">
				<img width="102" height="150" src="<?php echo URL ?>public/movies/<?php echo $item['thumbpath'] ?>" alt="poster of movie">
			</div>
			<div class="clearfix"></div>
		</div>
		<?php
		}
		?>
	</div>
</div>
<div class="clearfix"></div>
</div>