<div class="nav">
	<div class="nav-menu">
		<ul>
			<li><a href="<?php echo URL ?>index">Home</a></li>
			<li><a href="<?php echo URL ?>contact">Contact</a></li>
			<li><a href="<?php echo URL ?>techzone">Tech Zone</a></li>
			<li><a href="<?php echo URL ?>moviezone">Movie Zone</a></li>
			<li><a href="<?php echo URL ?>join">Join</a></li>
		</ul>
	</div>
</div>