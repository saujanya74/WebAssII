<!DOCTYPE html>
<html lang="en">
<head>
	<title>DVD Rental System</title>
	<meta charset = "utf-8" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL ?>public/Css/default.css">
	<script src="<?php echo URL ?>public/js/jquery.js"></script>
</head>
<body>
	<div class="full">
		<div class="heading">
			<h1>DVD Rental Sytem</h1>
		</div>
		