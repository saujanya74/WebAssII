<div class="contain-content">
<div class="section">
	<div class="First-release">
		<h1>Coming Soon</h1>
		<?php
		foreach ($this->newrelease as $item) {
		?>
		<div class="captain">
			<div class="movie-title">
				<h3><?php echo $item['title'] ?></h3>
			</div>
			<div class="inner">
				<p><B>Genre</B>:<?php echo $item['genre_name'] ?></p>
				<p><B>Director</B>:<?php echo $item['director_name'] ?></p>
				<p><B>Classification</B>:<?php echo $item['classification'] ?></p>
				<p><b>Starring:</b> <?php echo $item['actors'] ?></p>
				<p class="jun"><b><?php echo $item['tagline'] ?></b></p>
			</div>
			<div class="inner-right">
				<img src="public/movies/<?php echo $item['thumbpath'] ?>" alt="poster of movie">
			</div>
			<div class="movie-desc">
				<p><?php echo $item['plot'] ?></p>
			</div>
		</div>
		<?php 
		}
		?>
		<!-- <div class="captain">
			<div class="movie-title">
				<h3>Furious Seven</h3>
			</div>
			<div class="inner">
				<p><B>Genre</B>:Thriller</p>
				<p><B>Director</B>:Justin Lin</p>
				<p><B>Classification</B>:PG</p>
				<p><b>Starring:</b> Vin Diesel, Paul Walker, Jason Statham, Kurt Russell, Michelle Rodriguez and Dwayne Johnson.</p>
				<p class="jun"><b>One last ride.</b></p>
			</div>
			<div class="inner-right">
				<img src="public/images/furious.jpg" alt="poster of movie">
			</div>
			<div class="movie-desc">
				<p>Deckard Shaw seeks revenge against Dominic Toretto and his family for his comatose brother.</p>
			</div>
		</div> -->
	</div>
</div>