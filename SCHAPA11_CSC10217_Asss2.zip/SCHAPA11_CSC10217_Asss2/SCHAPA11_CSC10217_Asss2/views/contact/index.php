
	<div class="Aside">
		<h2>Contact Us</h2>
		<img src="public/images/Contact.jpg" alt="Gallery image">
		<div class="DVD">
			<p><b>Visit our DVD collection</b></p>
			<p><b>Phone:</b>0450073130</p>
			<p><b>Address:</b>38 Enderley Avenue<br> Surfers Paradise,<br>Queensland 4217</p>
			<p><b>Email:</b><a href="">DVDE-Rental.com.au</a></p>
		</div>
		<h3>Movie Rental System Location (Google Map)</h3>
		<div class="map-google">
			<p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3522.5050164622808!2d153.42675761458437!3d-28.009036546559027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b91050e74552f41%3A0xa24b0239258ab45b!2s38+Enderley+Ave%2C+Surfers+Paradise+QLD+4217!5e0!3m2!1sen!2sau!4v1559542313206!5m2!1sen!2sau" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></p> 
		</div>
	</div>
</div>