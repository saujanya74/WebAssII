<?php
	error_reporting(0);
	
	require 'config.php';

	require LIBS.'Bootstrap.php';
	require LIBS.'Controller.php';
	require LIBS.'Database.php';
	require LIBS.'Model.php';
	require LIBS.'View.php';

	require LIBS.'Session.php';

	$app = new Bootstrap();

?>