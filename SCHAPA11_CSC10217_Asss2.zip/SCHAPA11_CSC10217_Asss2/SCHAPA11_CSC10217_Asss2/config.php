<?php
if($_SERVER['HTTP_HOST'] == "localhost")
 {
	define(URL,'http://localhost/SCHAPA11_CSC10217_Asss2/');
	define(LIBS,'libs/');

	define(DB_TYPE, 'mysql');
	define(DB_HOST, 'localhost');
	define(DB_NAME, 'schapa11_moviezone_db');
	define(DB_USER, 'root');
	define(DB_PASS, '');
}
else
{
	define(URL,'http://infotech.scu.edu.au/~schapa11/');
	define(LIBS,'libs/');

	define(DB_TYPE, 'mysql');
	define(DB_HOST, 'localhost');
	define(DB_NAME, 'schapa11_moviezone_db');
	define(DB_USER, 'schapa11');
	define(DB_PASS, '23412769');
}

