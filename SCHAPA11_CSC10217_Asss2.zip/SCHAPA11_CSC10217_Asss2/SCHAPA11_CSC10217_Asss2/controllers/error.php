<?php 
	/**
	 * 
	 */
	class Errors
	{
		
		function __construct()
		{
			echo "page not found";
		}
	}
?>