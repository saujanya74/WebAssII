<?php
	/**
	* 
	*/
	class Moviezone extends Controller
	{
		
		public function __construct()
		{
			parent::__construct();
			Session::init();
		}

		public function index() {
			$this->view->movieslist = $this->model->getmovies();
			$this->view->render('moviezone/index',true);
		}
		public function showall() {
			$this->view->movieslist = $this->model->getallmovies();
			$this->view->render('moviezone/showall',true);
		}
		public function newreleases() {
			$this->view->movieslist = $this->model->getmovies();
			$this->view->render('moviezone/index',true);
		}
		public function actor() {
			$this->view->actorlist = $this->model->getactor();
			if(isset($_POST['btnSubmit'])) {
				$this->view->movieslist = $this->model->getactormovies($_POST['txtActorID']);
				$this->view->actorname = $this->model->getactorname($_POST['txtActorID']);
			}

			$this->view->render('moviezone/actor',true);
		}

		public function director() {
			$this->view->directorlist = $this->model->getdirector();
			if(isset($_POST['btnSubmit'])) {
				$this->view->movieslist = $this->model->getdirectormovies($_POST['txtDirectorID']);
				$this->view->directorname = $this->model->getdirectorname($_POST['txtDirectorID']);
			}

			$this->view->render('moviezone/director',true);
		}

		public function genre() {
			$this->view->genrelist = $this->model->getgenre();
			if(isset($_POST['btnSubmit'])) {
				$this->view->movieslist = $this->model->getgenremovies($_POST['txtGenreID']);
				$this->view->genrename = $this->model->getgenrename($_POST['txtGenreID']);
			}

			$this->view->render('moviezone/genre',true);
		}

		public function classification() {
			$this->view->classificationlist = $this->model->getclassification();
			if(isset($_POST['btnSubmit'])) {
				$this->view->movieslist = $this->model->getclassificationmovies($_POST['txtClassificationID']);
			}

			$this->view->render('moviezone/classification',true);
		}
		public function login()
		{
			$this->view->render('moviezone/memberlogin',true);
		}

		public function checklogin()
		{
			$loginstatus = $this->model->checklogin($_POST);
			$_SESSION['basket'] = array();

			if($loginstatus == 1)
			{
				header('location: '.URL.'moviezone');
			}
			else
			{
				header('location: '.URL.'moviezone/login');
			}
		}

		public function logout()
		{
			Session::destroy();
			header('location: '.URL.'moviezone');
		}

		public function addinbasket($movie_id)
		{
			// Session::set('basket',array());
			if(!in_array($movie_id, $_SESSION['basket']))
				array_push($_SESSION['basket'], $movie_id);
			header('location: '.$_POST['return_url']);
		}

		public function checkout()
		{
			$this->view->basketmovies = $this->model->basketmovies();
			$this->view->render('moviezone/checkout',true);
		}
	}
?>