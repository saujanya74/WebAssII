<?php 
	/**
	* 
	*/
	class Admin extends Controller
	{
		
		function __construct()
		{
			parent::__construct();
			Session::init();
			$logged = Session::get('loggedIn');
			if($logged == false)
			{
				Session::destroy();
				header('location: login');
				exit;
			}
		}

		public function index()
		{
			$this->view->render('admin/index',true,true);
		}

		public function logout()
		{
			Session::destroy();
			header('location: '.URL.'login');
		}


		// EDIT / DELETE MEMBER functions
		public function selectmember()
		{
			if(isset($_POST['member_id']))
				header('location: '.URL.'admin/memberdetail/'.$_POST['member_id']);

			$this->view->getMember = $this->model->getMember();
			$this->view->render('admin/selectmember',true,true);
		}

		public function memberdetail($memberid)
		{
			$this->view->memberdetail = $this->model->getmemberdetail($memberid);
			$this->view->render('admin/memberdetail',true,true);
		}

		public function updatemember()
		{
			$this->view->selected_member = $_POST['selected_member']." has been updated successfully";
			$this->model->updatemember($_POST);
			$this->view->render("admin/memberstatus",true,true);
		}

		public function deletemember()
		{
			$this->view->selected_member = $_POST['selected_member']." has been deleted successfully";
			$this->model->deletemember($_POST['member_id']);
			$this->view->render("admin/memberstatus",true,true);
		}

		// Movie
		public function movieform()
		{
			$this->view->director_list = $this->model->director_list();
			$this->view->studio_list = $this->model->studio_list();
			$this->view->genre_list = $this->model->genre_list();
			$this->view->actor_list = $this->model->actor_list();
			$this->view->render('admin/movieform',true, true);
		}

		public function addmovie()
		{
			$newname = time().$_FILES['poster']['name'];
			echo $newname;
			$tmp_name = $_FILES['poster']['tmp_name'];
			if(move_uploaded_file($tmp_name, "public/movies/".$newname))
			{
				$this->model->addmovie($_POST,$newname);
				$this->view->pagetitle = "Add Movie";
				$this->view->pagedesc = "Movie added successfully";
			}
			else{
				$this->view->pagetitle = "Add Movie";
				$this->view->pagedesc = "file not uploaded";
			}

			
			$this->view->render('admin/moviestatus',true, true);
		}

		public function selectmovie()
		{
			if(isset($_POST['movie_id']))
				header('location: '.URL.'admin/moviedetail/'.$_POST['movie_id']);

			$this->view->getmovie = $this->model->getmovie();
			$this->view->render('admin/selectmovie',true,true);
		}

		public function moviedetail($movieid)
		{
			$this->view->moviedetail = $this->model->getmoviedetail($movieid);
			$this->view->render('admin/moviedetail',true,true);
		}

		public function updatemovie()
		{
			$this->model->updatemovie($_POST);
			$this->view->pagetitle = "Update Movie";
			$this->view->pagedesc = "Movie updated successfully";
			$this->view->render('admin/moviestatus',true, true);
		}

		public function deletemovie()
		{
			$this->model->deletemovie($_POST['movie_id']);
			$this->view->pagetitle = "Delete Movie";
			$this->view->pagedesc = "Movie deleted successfully";
			$this->view->render('admin/moviestatus',true, true);
		}

	}
?>