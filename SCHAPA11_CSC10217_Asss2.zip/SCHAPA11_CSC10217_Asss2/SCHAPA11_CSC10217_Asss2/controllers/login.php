<?php 
	/**
	* 
	*/
	class Login extends Controller
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function index()
		{
			$this->view->render('login/index',true,true);
		}

		public function checklogin()
		{
			$this->model->checklogin();
		}
	}
?>