<?php  
	/**
	* 
	*/
	class Join extends Controller
	{
		
		function __construct()
		{
			parent::__construct();
			Session::init();
			$this->view->js = array('join/js/join.js','join/js/popup_events.js','join/js/events_handlers.js');
		}

		function index() {
			$_SESSION['add'] = true;
			$this->view->newrelease = $this->model->getnewrelease();
			$this->view->render('join/index');
		}
		public function addmember()
		{
			$this->model->addmember($_POST);

			$this->view->newrelease = $this->model->getnewrelease();
			$this->view->render('join/addmember');
		}
	}
?>