<?php
class Movie extends Controller {
	function __construct(){
		parent::__construct();
	}
	function index() {
		$this->view->newrelease = $this->model->getnewrelease();
		$this->view->render('movie/index');
	}
}
?>