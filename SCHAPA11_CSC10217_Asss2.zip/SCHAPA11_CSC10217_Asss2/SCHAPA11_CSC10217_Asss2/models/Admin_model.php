<?php 

	/**
	 * 
	 */
	class Admin_model extends Model
	{
		
		public function __construct()
		{
			parent::__construct();
		}

		// EDIT / DELETE MEMBER functions

		public function getMember()
		{
			$stm = $this->db->prepare("select member_id, surname, other_name, username from member order by surname asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function getmemberdetail($memberid)
		{
			$stm = $this->db->prepare("select * from member where member_id = ?");
			$stm->execute(array($memberid));
			return $stm->fetch();
		}

		public function updatemember($data)
		{
			$stm = $this->db->prepare("UPDATE member set
				surname = :surname ,
				other_name = :other_name,
				contact_method = :contact_method,
				email = :email,
				mobile = :mobile,
				landline = :landline,
				magazine = :magazine,
				street = :street,
				suburb = :suburb,
				postcode = :postcode,
				password = :password,
				occupation = :occupation
				WHERE member_id = :member_id
				");
				$stm->execute(array(
					':surname' => $data['Name'],
					':other_name' => $data['othername'],
					':contact_method' => $data['contactmethod'],
					':email' => $data['email'],
					':mobile' => $data['mobile'],
					':landline' => $data['landline_number'],
					':magazine' => $data['magazine'],
					':street' => $data['street_name'],
					':suburb' => $data['suburb_name'],
					':postcode' => $data['postal_code'],
					':password' => $data['password'],
					':occupation' => $data['occcupation'],
					':member_id' => $data['member_id']
				));
		}

		public function deletemember($memberid)
		{
			$stm = $this->db->prepare("delete from member where member_id = ?");
			$stm->execute(array($memberid));
		}

		// for movie page

		public function director_list()
		{
			$stm = $this->db->prepare("select * from director order by director_name asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function studio_list()
		{
			$stm = $this->db->prepare("select * from studio order by studio_name asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function genre_list()
		{
			$stm = $this->db->prepare("select * from genre order by genre_name asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function actor_list()
		{
			$stm = $this->db->prepare("select * from actor order by actor_name asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function addmovie($data,$poster)
		{
			$stm = $this->db->prepare("INSERT into movie set
				title					= :title,
				tagline					= :tagline,
				plot					= :plot,
				thumbpath				= :thumbpath,
				director_id				= :director_id,
				studio_id				= :studio_id,
				genre_id				= :genre_id,
				classification			= :classification,
				rental_period			= :rental_period,
				year					= :year,
				DVD_rental_price		= :DVD_rental_price,
				DVD_purchase_price		= :DVD_purchase_price,
				numDVD					= :numDVD,
				numDVDout				= :numDVDout,
				BluRay_rental_price		= :BluRay_rental_price,
				BluRay_purchase_price	= :BluRay_purchase_price,
				numBluRay				= :numBluRay,
				numBluRayOut			= :numBluRayOut
				");
				$stm->execute(array(
					':title' => $data['title'],
					':tagline' => $data['tagline'],
					':plot' => $data['plot'],
					':thumbpath' => $poster,
					':director_id' => $data['director_id'],
					':studio_id' => $data['studio_id'],
					':genre_id' => $data['genre_id'],
					':classification' => $data['classification'],
					':rental_period' => $data['rental_period'],
					':year' => $data['year'],
					':DVD_rental_price' => $data['DVD_rental_price'],
					':DVD_purchase_price' => $data['DVD_purchase_price'],
					':numDVD' => $data['numDVD'],
					':numDVDout' => $data['numDVDout'],
					':BluRay_rental_price' => $data['BluRay_rental_price'],
					':BluRay_purchase_price' => $data['BluRay_purchase_price'],
					':numBluRay' => $data['numBluRay'],
					':numBluRayOut' => $data['numBluRayOut']
				));
				// $stm->debugDumpParams();
				//die(print_r($stm->errorInfo()));
		}

		public function getmovie()
		{
			$stm = $this->db->prepare("select movie_id, title, year from movie order by title asc");
			$stm->execute();
			return $stm->fetchAll();
		}

		public function getmoviedetail($movieid)
		{
			$stm = $this->db->prepare("select * from movie where movie_id = ?");
			$stm->execute(array($movieid));
			return $stm->fetch();
		}

		public function updatemovie($data)
		{
			$stm = $this->db->prepare("UPDATE movie set
				title					= :title,
				tagline					= :tagline,
				rental_period			= :rental_period,
				year					= :year,
				DVD_rental_price		= :DVD_rental_price,
				DVD_purchase_price		= :DVD_purchase_price,
				numDVD					= :numDVD,
				numDVDout				= :numDVDout,
				BluRay_rental_price		= :BluRay_rental_price,
				BluRay_purchase_price	= :BluRay_purchase_price,
				numBluRay				= :numBluRay,
				numBluRayOut			= :numBluRayOut
				WHERE
				movie_id 				= :movie_id
				");
				$stm->execute(array(
					':title' => $data['title'],
					':tagline' => $data['tagline'],
					':rental_period' => $data['rental_period'],
					':year' => $data['year'],
					':DVD_rental_price' => $data['DVD_rental_price'],
					':DVD_purchase_price' => $data['DVD_purchase_price'],
					':numDVD' => $data['numDVD'],
					':numDVDout' => $data['numDVDout'],
					':BluRay_rental_price' => $data['BluRay_rental_price'],
					':BluRay_purchase_price' => $data['BluRay_purchase_price'],
					':numBluRay' => $data['numBluRay'],
					':numBluRayOut' => $data['numBluRayOut'],
					':movie_id' => $data['movie_id']
				));
				// $stm->debugDumpParams();
				//die(print_r($stm->errorInfo()));
		}

		public function deletemovie($movieid)
		{
			$stm = $this->db->prepare("delete from movie where movie_id = ?");
			$stm->execute(array($movieid));
		}
	}
?>