<?php 

	/**
	 * 
	 */
	class Login_model extends Model
	{
		
		public function __construct()
		{
			parent::__construct();
		}

		public function checklogin()
		{

			$stm = $this->db->prepare("select userid, fullname from users where `uname` = :user and `pass` = MD5(:passd)");
			$stm->execute(array(
				':user' => $_POST['username'],
				':passd' => $_POST['password']
			));
			$data = $stm->fetch();
			$count = $stm->rowCount();
			if($count > 0)
			{
				Session::init();
				Session::set('loggedIn', true);
				Session::set('fullname', $data['fullname']);
				header('location: '.URL.'admin');
			}
			else
			{
				header('location: '.URL.'login');
			}
		}
	}
?>