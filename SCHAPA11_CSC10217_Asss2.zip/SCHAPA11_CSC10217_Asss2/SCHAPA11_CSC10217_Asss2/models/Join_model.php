<?php
	/**
	* 
	*/
	class Join_model extends Model
	{
		
		function __construct()
		{
			parent::__construct();
			$this->getnewrelease();
		}
		public function getnewrelease()
		{
			$stm = $this->db->prepare("select * from movie_detail order by RAND() limit 0,2");
			$stm->execute();

			return $data = $stm->fetchAll();
		}

		public function addmember($data)
		{
			if($_SESSION['add'] == true) {
				$stm = $this->db->prepare("INSERT into member  
				(surname, other_name, contact_method, email, mobile, landline, magazine, street, suburb, postcode, username, password, occupation, join_date)
				VALUES (:surname, :other_name, :contact_method, :email, :mobile, :landline, :magazine, :street, :suburb, :postcode, :username, :password, :occupation, :join_date)
				");
				$stm->execute(array(
					':surname' => $data['Name'],
					':other_name' => $data['othername'],
					':contact_method' => $data['contactmethod'],
					':email' => $data['email'],
					':mobile' => $data['mobile'],
					':landline' => $data['landline_number'],
					':magazine' => $data['magazine'],
					':street' => $data['street_name'],
					':suburb' => $data['suburb_name'],
					':postcode' => $data['postal_code'],
					':username' => $data['username'],
					':password' => $data['password'],
					':occupation' => $data['occcupation'],
					':join_date' => date("Y-m-d")
				));
			}

			unset($_SESSION['add']);
		}
	}
?>